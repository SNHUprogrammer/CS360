package com.example.projectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

/**
 * This class is a data access object for
 * a database containing events.
 *
 * @author Ryan LeChien
 */
public class DBDAO extends SQLiteOpenHelper
{
    // column names for the database
    protected static final String dbName = "Events.db";
    protected static final String tableName = "events";
    private static final String title = "title";
    private static final String date = "date";
    private static final String desc = "description";
    private Context context;


    DBDAO(@Nullable Context context)
    {
        super(context, dbName, null, 1);
        this.context = context;
    }

    // create the database on create
    @Override
    public void onCreate(SQLiteDatabase db)
    {

        String query =
                "CREATE TABLE " + tableName +
                        "(_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        title + " TEXT, " +
                        date+ " TEXT, " +
                        desc + " TEXT)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1)
    {
        // do something I suppose
    }

    /**
     * A method to implement the C in CRUD
     *
     * @param date
     * @param title
     * @param description
     * @return true if added
     */
    public boolean create(String title, String date, String description)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        // put the event components into an encapsulation
        cv.put(this.title, title);
        cv.put(this.date, date);
        cv.put(this.desc, description);

        // will return true if successful
        return -1 != db.insert(tableName, null, cv);
    }

    /**
     * A method to implement the R in CRUD
     *
     * @return a cursor on a list of the events from the database
     */
    public Cursor read()
    {
        return this.getReadableDatabase().rawQuery( ("SELECT * FROM " + tableName), null);
    }

    /**
     * A method to implement the D in CRUD
     *
     * For the purposes of this app, this
     * method wipes but does not drop
     * the database.
     *
     */
    public void delete()
    {
        this.getReadableDatabase().execSQL(("DELETE FROM " + tableName + ";"));
    }
}