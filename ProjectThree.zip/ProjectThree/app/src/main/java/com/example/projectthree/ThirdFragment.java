package com.example.projectthree;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.projectthree.databinding.FragmentThirdBinding;

/**
 * The third fragment, which offers
 * multiple text boxes for creating
 * events.
 *
 * @author Ryan LeChien
 */
public class ThirdFragment extends Fragment
{

    private FragmentThirdBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ){

        binding = FragmentThirdBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        binding.createEvent.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                try
                {
                    // create an entry with the           title,                                   date,                                  and description
                    MainActivity.eventsDB.create(binding.eventTitle.getText().toString(), binding.eventDate.getText().toString(), binding.eventDescription.getText().toString());
                }
                catch (Exception e) // for the sake of getting on with life
                {
                    // make a toast to the failed event
                    Toast.makeText(getActivity(), "Event not created! ", Toast.LENGTH_LONG).show();
                }

                // make a toast to the new event
                Toast.makeText(getActivity(), "Event created!", Toast.LENGTH_LONG).show();

                // navigate to the second fragment
                NavHostFragment.findNavController(ThirdFragment.this)
                        .navigate(R.id.action_ThirdFragment_to_SecondFragment);
            }
        });
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        binding = null;
    }
}