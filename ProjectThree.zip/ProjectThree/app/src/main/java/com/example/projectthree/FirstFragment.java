package com.example.projectthree;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.projectthree.databinding.FragmentFirstBinding;


/**
 * FirstFragment
 *
 * The first fragment which displays the login screen
 *
 * @author Ryan LeChien
 */
public class FirstFragment extends Fragment
{

    private FragmentFirstBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ){

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        // on successful login
        binding.login.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                // welcome the user specifically
                Toast.makeText(getActivity(), "Welcome back " + binding.username.getText() + "!", Toast.LENGTH_LONG).show();

                // prompt permission
                promptSMS();

                // navigate to second fragment
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
            }
        });
        binding.newUser.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                // welcome generic new user
                Toast.makeText(getActivity(), "Welcome new user!", Toast.LENGTH_LONG).show();

                // prompt permission
                promptSMS();

                // navigate to second fragment
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
            }
        });
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        binding = null;
    }

    /**
     * Private helper method for prompting for SMS permission
     *
     * @TODO implement actual notifications
     */
    private void promptSMS()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Allow SMS notifications?");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int i)
            {
                //dialog.dismiss();
                Toast.makeText(getActivity(),"SMS permission allowed",Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int i)
            {
                //dialog.dismiss();
                Toast.makeText(getActivity(),"SMS permission denied",Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
    }

}